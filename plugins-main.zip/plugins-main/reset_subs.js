(function () {
    'use strict';

    Lampa.Storage.set('webos_subs_params','{}');
})();
