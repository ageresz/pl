(function () {
    'use strict';

    Lampa.Storage.set('is_true_mobile', 'false');
})();
